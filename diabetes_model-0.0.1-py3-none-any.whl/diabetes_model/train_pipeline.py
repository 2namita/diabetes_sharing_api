import sys


from pathlib import Path
file = Path(__file__).resolve()
parent, root = file.parent, file.parents[1]
sys.path.append(str(root))

import pandas as pd
from sklearn.model_selection import train_test_split, KFold, cross_val_score
from sklearn.metrics import mean_squared_error, r2_score, make_scorer
import numpy as np

from diabetes_model.config.core import config
from diabetes_model.pipeline import diabetes_pipe
from diabetes_model.processing.data_manager import load_dataset, save_pipeline

def run_training() -> None:
    
    """
    Train the model.
    """

    # read training data
    data = load_dataset(file_name = config.app_config_.training_data_file)

    # divide train and test
    X_train, X_test, y_train, y_test = train_test_split(
        
        data[config.model_config_.features],     # predictors
        data[config.model_config_.target],       # target
        test_size = config.model_config_.test_size,
        random_state=config.model_config_.random_state,   # set the random seed here for reproducibility
    )

    kfold = KFold(n_splits=config.model_config_.k_fold, shuffle=True, random_state=config.model_config_.random_state)
    # Print the model performance
    # 1️⃣ R² Cross-Validation
    r2_scores = cross_val_score(diabetes_pipe, data[config.model_config_.features], data[config.model_config_.target], cv=kfold, scoring="r2")
    print("R² scores for each fold:", r2_scores)
    print("Average R² score:", np.mean(r2_scores))

    # 2️⃣ MSE Cross-Validation
    mse_scores = cross_val_score(
        diabetes_pipe, data[config.model_config_.features], data[config.model_config_.target], cv=kfold,
        scoring=make_scorer(mean_squared_error)
    )
    print("MSE scores for each fold:", mse_scores)
    print("Average MSE:", np.mean(mse_scores))



    # Pipeline fitting
    diabetes_pipe.fit(X_train, y_train)
    y_pred = diabetes_pipe.predict(X_test)



    # Calculate the score/error
    print("R2 score:", round(r2_score(y_test, y_pred), 2))
    print("Mean squared error:", mean_squared_error(y_test, y_pred))

    # persist trained model
    save_pipeline(pipeline_to_persist = diabetes_pipe)
    
if __name__ == "__main__":
    run_training()
